import type { FastifyInstance, FastifyReply, FastifyRequest } from 'fastify';
import { authMiddleware } from '../auth/auth-middleware.js';
import { requireRole } from '../auth/role-middleware.js';
import { requireZaloAccess } from '../zalo/zalo-access-middleware.js';
import { getAiConfig, getAiUsage, updateAiConfig, generateAiOutput } from './ai-service.js';
import { getAvailableProviders } from './provider-registry.js';
import { scoreConversation, batchScoreConversations } from './service-scoring.js';
import { logger } from '../../shared/utils/logger.js';
import { prisma } from '../../shared/database/prisma-client.js';

async function assertConversationReadAccess(request: FastifyRequest, reply: FastifyReply, conversationId: string) {
  const user = request.user!;
  const conversation = await prisma.conversation.findFirst({
    where: { id: conversationId, orgId: user.orgId },
    select: { id: true, zaloAccountId: true },
  });
  if (!conversation) {
    reply.status(404).send({ error: 'Conversation not found' });
    return null;
  }
  if (['owner', 'admin'].includes(user.role)) return conversation;

  const access = await prisma.zaloAccountAccess.findFirst({
    where: { zaloAccountId: conversation.zaloAccountId, userId: user.id },
    select: { permission: true },
  });
  if (!access) {
    reply.status(403).send({ error: 'Không có quyền truy cập tài khoản Zalo này' });
    return null;
  }
  return conversation;
}

function getStatusFromError(err: unknown, fallback: string) {
  const message = err instanceof Error ? err.message : fallback;
  const status = message.includes('quota exceeded') ? 429 : message.includes('not found') ? 404 : message.includes('disabled') || message.includes('configured') ? 400 : 500;
  return { message, status };
}

function sendHandledError(reply: FastifyReply, err: unknown, fallback: string) {
  const handled = getStatusFromError(err, fallback);
  const safeMessage = handled.status === 500 ? fallback : handled.message;
  return reply.status(handled.status).send({ error: safeMessage });
}


export async function aiRoutes(app: FastifyInstance) {
  app.addHook('preHandler', authMiddleware);

  /* Returns available AI providers + their models (based on .env config) */
  app.get('/api/v1/ai/providers', async () => {
    return getAvailableProviders();
  });

  app.get('/api/v1/ai/config', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      return await getAiConfig(request.user!.orgId);
    } catch (err) {
      logger.error('[ai] Get config error:', err);
      return reply.status(500).send({ error: 'Failed to fetch AI config' });
    }
  });

  app.put('/api/v1/ai/config', { preHandler: requireRole('owner', 'admin') }, async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const body = request.body as { provider?: string; model?: string; maxDaily?: number; enabled?: boolean };
      if (body.maxDaily !== undefined && body.maxDaily < 1) return reply.status(400).send({ error: 'maxDaily must be at least 1' });
      return await updateAiConfig(request.user!.orgId, body);
    } catch (err) {
      logger.error('[ai] Update config error:', err);
      return reply.status(500).send({ error: 'Failed to update AI config' });
    }
  });

  app.get('/api/v1/ai/usage', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      return await getAiUsage(request.user!.orgId);
    } catch (err) {
      logger.error('[ai] Usage error:', err);
      return reply.status(500).send({ error: 'Failed to fetch AI usage' });
    }
  });

  app.post('/api/v1/ai/suggest', async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const body = request.body as { conversationId?: string; messageId?: string };
      if (!body.conversationId) return reply.status(400).send({ error: 'conversationId is required' });
      const access = await assertConversationReadAccess(request, reply, body.conversationId);
      if (!access) return;
      return await generateAiOutput({ orgId: request.user!.orgId, conversationId: body.conversationId, messageId: body.messageId, type: 'reply_draft' });
    } catch (err) {
      logger.error('[ai] Suggest error:', err);
      return sendHandledError(reply, err, 'Failed to generate AI suggestion');
    }
  });

  app.post('/api/v1/ai/summarize/:id', { preHandler: requireZaloAccess('read') }, async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { id } = request.params as { id: string };
      return await generateAiOutput({ orgId: request.user!.orgId, conversationId: id, type: 'summary' });
    } catch (err) {
      logger.error('[ai] Summary error:', err);
      return sendHandledError(reply, err, 'Failed to summarize conversation');
    }
  });

  app.post('/api/v1/ai/sentiment/:id', { preHandler: requireZaloAccess('read') }, async (request: FastifyRequest, reply: FastifyReply) => {
    try {
      const { id } = request.params as { id: string };
      return await generateAiOutput({ orgId: request.user!.orgId, conversationId: id, type: 'sentiment' });
    } catch (err) {
      logger.error('[ai] Sentiment error:', err);
      return sendHandledError(reply, err, 'Failed to analyze sentiment');
    }
  });

  /**
   * POST /api/v1/ai/service-score/:id
   * Chấm Điểm Phục Vụ cho một conversation cụ thể.
   * Quyền: owner | admin (chỉ quản lý mới được chấm/xem kết quả chi tiết).
   */
  app.post(
    '/api/v1/ai/service-score/:id',
    { preHandler: requireRole('owner', 'admin') },
    async (request: FastifyRequest, reply: FastifyReply) => {
      try {
        const { id } = request.params as { id: string };
        // Kiểm tra conversation thuộc org
        const conv = await prisma.conversation.findFirst({
          where: { id, orgId: request.user!.orgId },
          select: { id: true },
        });
        if (!conv) return reply.status(404).send({ error: 'Conversation not found' });

        const result = await scoreConversation(id, request.user!.orgId);
        return result;
      } catch (err) {
        logger.error('[ai] Service-score error:', err);
        return sendHandledError(reply, err, 'Failed to score conversation');
      }
    },
  );

  /**
   * POST /api/v1/ai/service-score/batch
   * Chấm Điểm Phục Vụ hàng loạt cho org (dùng cronjob hoặc trigger thủ công).
   * Body: { maxAgeHours?: number, activeWithinHours?: number, batchLimit?: number }
   * Quyền: owner | admin.
   */
  app.post(
    '/api/v1/ai/service-score/batch',
    { preHandler: requireRole('owner', 'admin') },
    async (request: FastifyRequest, reply: FastifyReply) => {
      try {
        const body = (request.body as Record<string, unknown>) ?? {};
        const maxAgeHours = typeof body.maxAgeHours === 'number' ? body.maxAgeHours : 24;
        const activeWithinHours = typeof body.activeWithinHours === 'number' ? body.activeWithinHours : 48;
        const batchLimit = typeof body.batchLimit === 'number' ? Math.min(body.batchLimit, 200) : 50;

        const result = await batchScoreConversations({
          orgId: request.user!.orgId,
          maxAgeHours,
          activeWithinHours,
          batchLimit,
        });
        return result;
      } catch (err) {
        logger.error('[ai] Service-score batch error:', err);
        return sendHandledError(reply, err, 'Failed to run batch scoring');
      }
    },
  );

  /**
   * GET /api/v1/ai/service-score/:id
   * Lấy kết quả chấm điểm đã có của một conversation.
   */
  app.get(
    '/api/v1/ai/service-score/:id',
    { preHandler: requireRole('owner', 'admin') },
    async (request: FastifyRequest, reply: FastifyReply) => {
      try {
        const { id } = request.params as { id: string };
        const conv = await prisma.conversation.findFirst({
          where: { id, orgId: request.user!.orgId },
          select: {
            id: true,
            serviceScore: true,
            serviceLabel: true,
            serviceScoreData: true,
            serviceScoreAt: true,
            managerActionRequired: true,
            contact: { select: { id: true, fullName: true, crmName: true } },
          },
        });
        if (!conv) return reply.status(404).send({ error: 'Conversation not found' });
        return conv;
      } catch (err) {
        logger.error('[ai] Get service-score error:', err);
        return reply.status(500).send({ error: 'Failed to fetch service score' });
      }
    },
  );
}
