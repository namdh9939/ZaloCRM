/**
 * Composable for contact (khách hàng) management:
 * - List with filters, pagination
 * - CRUD operations
 * - CRM pipeline status
 */
import { ref, reactive } from 'vue';
import { api } from '@/api/index';

export interface Contact {
  id: string;
  fullName: string | null;
  crmName?: string | null;
  phone: string | null;
  email?: string | null;
  avatarUrl?: string | null;
  source: string | null;
  status: string | null;
  zaloUid?: string | null;
  nextAppointment: string | null;
  convertedAt?: string | null;
  notes: string | null;
  tags: string[];
  assignedUserId?: string | null;
  assignedUser?: { fullName: string } | null;
  createdAt?: string;
  firstContactDate?: string | null;
  leadScore: number;
  serviceScore?: number | null;
  serviceLabel?: 'success' | 'info' | 'warning' | 'error' | null;
  lastActivity: string | null;
  mergedInto: string | null;
  metadata?: Record<string, unknown> | null;
  isGroup?: boolean;
  lostReason?: string | null;
  lostNote?: string | null;
  contactType?: string;
  // AI-suggested status (consulting | quoting | nurturing | lost). Null when no
  // pending suggestion. UI shows a badge with Apply/Reject buttons.
  suggestedStatus?: string | null;
  suggestedStatusReason?: string | null;
  suggestedStatusAt?: string | null;
}

export interface DuplicateGroup {
  id: string;
  contactIds: string[];
  matchType: string;
  confidence: number;
  resolved: boolean;
  createdAt: string;
  contacts: Contact[];
}

export interface ContactFilters {
  search: string;
  source: string;
  status: string;
}

export const SOURCE_OPTIONS = [
  { text: 'Khóa học TKSXN', value: 'KH_TKSXN' },
  { text: 'Fanpage anh Nam', value: 'FP_NAM' },
  { text: 'Fanpage NCM', value: 'FP_NCM' },
  { text: 'Khóa học XNLĐ', value: 'KH_XNLD' },
  { text: 'Tự tìm', value: 'TU_TIM' },
  { text: 'Hotline NCM', value: 'HOTLINE_NCM' },
];

// Nguồn dành riêng cho nhóm Zalo. Nhóm có nguồn 'TLXN' sẽ lên dashboard CSKH.
export const GROUP_SOURCE_OPTIONS = [
  { text: 'TLXN (CSKH)', value: 'TLXN' },
  { text: 'Khóa học', value: 'KHOA_HOC' },
  { text: 'Nội bộ', value: 'NOI_BO' },
];

export const LOST_REASON_OPTIONS = [
  { text: 'Giá cao', value: 'price' },
  { text: 'Chưa sẵn sàng / chưa có nhu cầu', value: 'not_ready' },
  { text: 'Chọn đối thủ', value: 'competitor' },
  { text: 'Không hợp nhu cầu', value: 'not_fit' },
  { text: 'Mất liên lạc', value: 'lost_contact' },
  { text: 'Khác', value: 'other' },
];

export const STATUS_OPTIONS = [
  { text: 'Lead mới', value: 'new' },
  { text: 'Đang tư vấn', value: 'consulting' },
  { text: 'Đang báo giá', value: 'quoting' },
  { text: 'Nuôi dưỡng', value: 'nurturing' },
  { text: 'Chuyển đổi', value: 'converted' },
  { text: 'Thất bại', value: 'lost' },
];

export function useContacts() {
  const contacts = ref<Contact[]>([]);
  const total = ref(0);
  const loading = ref(false);
  const saving = ref(false);
  const deleting = ref(false);

  const filters = reactive<ContactFilters & { threadType?: string; zaloAccountId?: string }>({
    search: '',
    source: '',
    status: '',
    threadType: '',
    zaloAccountId: '',
  });

  const pagination = reactive({ page: 1, limit: 20 });

  async function fetchContacts(append = false) {
    if (!append) pagination.page = 1;
    loading.value = true;
    try {
      const res = await api.get('/contacts', {
        params: {
          page: pagination.page,
          limit: pagination.limit,
          search: filters.search || undefined,
          source: filters.source || undefined,
          status: filters.status || undefined,
          threadType: filters.threadType || undefined,
          zaloAccountId: filters.zaloAccountId || undefined,
        },
      });
      const newItems = res.data.contacts ?? res.data;
      if (append) {
        contacts.value = [...contacts.value, ...newItems];
      } else {
        contacts.value = newItems;
      }
      total.value = res.data.total ?? (append ? total.value : contacts.value.length);
    } catch (err) {
      console.error('Failed to fetch contacts:', err);
    } finally {
      loading.value = false;
    }
  }

  async function fetchContact(id: string): Promise<Contact | null> {
    try {
      const res = await api.get(`/contacts/${id}`);
      return res.data;
    } catch (err) {
      console.error('Failed to fetch contact:', err);
      return null;
    }
  }

  async function createContact(payload: Partial<Contact>): Promise<Contact | null> {
    saving.value = true;
    try {
      const res = await api.post('/contacts', payload);
      await fetchContacts();
      return res.data;
    } catch (err) {
      console.error('Failed to create contact:', err);
      return null;
    } finally {
      saving.value = false;
    }
  }

  async function updateContact(id: string, payload: Partial<Contact>): Promise<Contact | null> {
    saving.value = true;
    try {
      const res = await api.put(`/contacts/${id}`, payload);
      const idx = contacts.value.findIndex(c => c.id === id);
      if (idx !== -1) contacts.value[idx] = res.data;
      return res.data;
    } catch (err) {
      console.error('Failed to update contact:', err);
      return null;
    } finally {
      saving.value = false;
    }
  }

  async function deleteContact(id: string): Promise<boolean> {
    deleting.value = true;
    try {
      await api.delete(`/contacts/${id}`);
      await fetchContacts();
      return true;
    } catch (err) {
      console.error('Failed to delete contact:', err);
      return false;
    } finally {
      deleting.value = false;
    }
  }

  async function assignContact(id: string, assignedUserId: string | null): Promise<Contact | null> {
    try {
      const res = await api.patch(`/contacts/${id}/assign`, { assignedUserId });
      return res.data;
    } catch (err) {
      console.error('Failed to assign contact:', err);
      return null;
    }
  }

  async function bulkAssignContacts(contactIds: string[], assignedUserId: string | null): Promise<number> {
    try {
      const res = await api.post('/contacts/bulk-assign', { contactIds, assignedUserId });
      await fetchContacts();
      return res.data.updated ?? 0;
    } catch (err) {
      console.error('Failed to bulk-assign contacts:', err);
      return 0;
    }
  }

  function resetFilters() {
    filters.search = '';
    filters.source = '';
    filters.status = '';
    pagination.page = 1;
    fetchContacts();
  }

  async function applySuggestedStatus(contactId: string): Promise<Contact | null> {
    try {
      const res = await api.post(`/contacts/${contactId}/suggested-status/apply`);
      return res.data.contact ?? null;
    } catch (err) {
      console.error('Failed to apply suggested status:', err);
      return null;
    }
  }

  async function rejectSuggestedStatus(contactId: string): Promise<boolean> {
    try {
      await api.post(`/contacts/${contactId}/suggested-status/reject`);
      return true;
    } catch (err) {
      console.error('Failed to reject suggested status:', err);
      return false;
    }
  }

  async function detectSuggestedStatus(contactId: string): Promise<{ suggestedStatus: string | null; statusReason: string } | null> {
    try {
      const res = await api.post(`/contacts/${contactId}/suggested-status/detect`);
      return res.data.result ?? null;
    } catch (err) {
      console.error('Failed to detect suggested status:', err);
      return null;
    }
  }

  return {
    contacts, total, loading, saving, deleting,
    filters, pagination,
    fetchContacts, fetchContact,
    createContact, updateContact, deleteContact,
    assignContact, bulkAssignContacts,
    resetFilters,
    applySuggestedStatus, rejectSuggestedStatus, detectSuggestedStatus,
  };
}

export function useContactIntelligence() {
  const duplicateGroups = ref<DuplicateGroup[]>([]);
  const duplicateTotal = ref(0);
  const loadingDuplicates = ref(false);
  const merging = ref(false);

  async function fetchDuplicateGroups(page = 1, limit = 20) {
    loadingDuplicates.value = true;
    try {
      const res = await api.get('/contacts/duplicates', {
        params: { page, limit, resolved: 'false' },
      });
      duplicateGroups.value = res.data.groups ?? [];
      duplicateTotal.value = res.data.total ?? 0;
    } catch (err) {
      console.error('Failed to fetch duplicate groups:', err);
    } finally {
      loadingDuplicates.value = false;
    }
  }

  async function mergeDuplicateGroup(groupId: string, primaryContactId: string): Promise<boolean> {
    merging.value = true;
    try {
      await api.post(`/contacts/duplicates/${groupId}/merge`, { primaryContactId });
      return true;
    } catch (err) {
      console.error('Failed to merge contacts:', err);
      return false;
    } finally {
      merging.value = false;
    }
  }

  async function recomputeIntelligence(): Promise<boolean> {
    try {
      await api.post('/contacts/intelligence/recompute');
      return true;
    } catch (err) {
      console.error('Failed to trigger recompute:', err);
      return false;
    }
  }

  return {
    duplicateGroups, duplicateTotal, loadingDuplicates, merging,
    fetchDuplicateGroups, mergeDuplicateGroup, recomputeIntelligence,
  };
}
