<template>
  <div
    class="message-thread d-flex flex-column flex-grow-1"
    style="height: 100%; position: relative;"
    @dragover.prevent="onDragOver"
    @dragleave.prevent="onDragLeave"
    @drop.prevent="onDrop"
  >
    <!-- Drop zone overlay -->
    <div v-if="isDragging && conversation" class="drop-overlay">
      <v-icon icon="mdi-cloud-upload-outline" size="64" color="primary" />
      <div class="text-h6 mt-2" style="color: #00F2FF;">Thả file để gửi</div>
      <div class="text-caption text-grey mt-1">Ảnh, video, tài liệu — tối đa 50MB/file</div>
    </div>

    <!-- Empty state -->
    <div v-if="!conversation" class="d-flex align-center justify-center flex-grow-1">
      <div class="text-center text-grey">
        <v-icon icon="mdi-chat-outline" size="96" color="grey-lighten-2" />
        <p class="text-h6 mt-4">Chọn cuộc trò chuyện</p>
      </div>
    </div>

    <template v-else>
      <!-- Header -->
      <div class="pa-3 d-flex align-center" style="border-bottom: 1px solid var(--border-glow, rgba(0,242,255,0.1));">
        <v-avatar size="36" color="grey-lighten-2" class="mr-3">
          <v-icon v-if="conversation.threadType === 'group'" icon="mdi-account-group" />
          <v-img v-else-if="conversation.contact?.avatarUrl" :src="conversation.contact.avatarUrl" />
          <v-icon v-else icon="mdi-account" />
        </v-avatar>
        <div class="flex-grow-1">
          <div class="font-weight-medium">{{ conversation.contact?.fullName || 'Unknown' }}</div>
          <div class="text-caption text-grey">{{ conversation.zaloAccount?.displayName || 'Zalo' }}</div>
        </div>
        <v-btn size="small" variant="tonal" color="primary" class="mr-2" :loading="aiSuggestionLoading" @click="$emit('ask-ai')">
          Ask AI
        </v-btn>
        <v-btn
          :icon="showContactPanel ? 'mdi-account-details' : 'mdi-account-details-outline'"
          size="small" variant="text"
          :color="showContactPanel ? 'primary' : undefined"
          @click="$emit('toggle-contact-panel')"
        />
      </div>

      <!-- Messages -->
      <div ref="messagesContainer" class="flex-grow-1 overflow-y-auto pa-3 chat-messages-area">
        <v-progress-linear v-if="loading" indeterminate color="primary" class="mb-2" />
        <div v-for="msg in messages" :key="msg.id" class="mb-2 d-flex" :class="msg.senderType === 'self' ? 'justify-end' : 'justify-start'">
          <div style="max-width: 70%;">
            <div v-if="conversation.threadType === 'group' && msg.senderType !== 'self'" class="text-caption mb-1">
              <span v-if="msg.senderName" style="color: #00F2FF; font-weight: 500;">{{ msg.senderName }}</span>
              <span v-else style="color: #888; font-style: italic; opacity: 0.7;">Không rõ người gửi</span>
            </div>
            <div class="message-bubble pa-2 px-3 rounded-lg" :class="msg.senderType === 'self' ? 'bg-primary text-white' : 'bg-white'" style="word-wrap: break-word;">
              <!-- Deleted -->
              <div v-if="msg.isDeleted" class="text-decoration-line-through font-italic" style="opacity: 0.6;">
                {{ msg.content || '(tin nhắn)' }}<span class="text-caption"> (đã thu hồi)</span>
              </div>
              <!-- Image -->
              <div v-else-if="getImageUrl(msg)">
                <img :src="getImageUrl(msg)!" alt="Hình ảnh" class="chat-image" @click="previewImageUrl = getImageUrl(msg)!" />
              </div>
              <!-- File/PDF -->
              <div v-else-if="getFileInfo(msg)" class="file-card">
                <v-icon size="20" class="mr-2" color="info">mdi-file-document-outline</v-icon>
                <div class="flex-grow-1">
                  <div class="text-body-2 font-weight-medium">{{ getFileInfo(msg)!.name }}</div>
                  <div class="text-caption" style="opacity: 0.6;">{{ getFileInfo(msg)!.size }}</div>
                </div>
                <v-btn v-if="getFileInfo(msg)!.href" icon size="x-small" variant="text" @click="openFile(getFileInfo(msg)!.href)">
                  <v-icon size="16">mdi-download</v-icon>
                </v-btn>
              </div>
              <!-- Video player -->
              <div v-else-if="msg.contentType === 'video' && getVideoInfo(msg)" class="video-wrap">
                <video
                  :src="getVideoInfo(msg)!.src"
                  :poster="getVideoInfo(msg)!.poster"
                  controls
                  preload="metadata"
                  class="chat-video"
                />
                <div v-if="getVideoInfo(msg)!.sizeLabel" class="text-caption mt-1" style="opacity: 0.6;">{{ getVideoInfo(msg)!.sizeLabel }}</div>
              </div>
              <!-- Voice player -->
              <div v-else-if="msg.contentType === 'voice' && getVoiceUrl(msg)">
                <audio :src="getVoiceUrl(msg)!" controls preload="none" class="chat-audio" />
              </div>
              <!-- Sticker / GIF / unknown video fallback -->
              <div v-else-if="msg.contentType === 'sticker'">🏷️ Sticker</div>
              <div v-else-if="msg.contentType === 'video'">🎥 Video (không tải được)</div>
              <div v-else-if="msg.contentType === 'voice'">🎤 Tin nhắn thoại</div>
              <div v-else-if="msg.contentType === 'gif'">GIF</div>
              <!-- Reminder/Calendar (legacy inline renderer kept for backward compat) -->
              <div v-else-if="isReminderMessage(msg)" class="reminder-card">
                <div class="d-flex align-center mb-1">
                  <v-icon size="16" color="warning" class="mr-1">mdi-calendar-clock</v-icon>
                  <span class="text-caption font-weight-bold" style="color: #FFB74D;">Nhắc hẹn</span>
                </div>
                <div class="text-body-2">{{ getReminderTitle(msg) }}</div>
                <div v-if="getReminderTime(msg)" class="text-caption mt-1" style="opacity: 0.7;">
                  <v-icon size="12" class="mr-1">mdi-clock-outline</v-icon>{{ getReminderTime(msg) }}
                </div>
                <v-btn size="x-small" variant="tonal" color="warning" class="mt-2" prepend-icon="mdi-calendar-sync" @click="syncAppointment(msg)">
                  Đồng bộ lịch
                </v-btn>
              </div>
              <!-- Special message types (bank_transfer, call, qr_code, poll, note, forwarded, rich) -->
              <SpecialMessageRenderer
                v-else-if="isSpecialType(msg.contentType)"
                :type="msg.contentType"
                :content="parseContent(msg.content)"
              />
              <!-- Default text -->
              <div v-else><LinkifyText :text="parseDisplayContent(msg.content)" /></div>
              <!-- Timestamp -->
              <div class="text-caption mt-1 msg-time" :class="msg.senderType === 'self' ? 'msg-time-self' : 'msg-time-contact'" style="font-size: 0.7rem;">
                {{ formatMessageTime(msg.sentAt) }}
              </div>
            </div>
          </div>
        </div>
        <div v-if="!loading && messages.length === 0" class="text-center pa-8 text-grey">Chưa có tin nhắn</div>
      </div>

      <!-- Input -->
      <div class="pa-2 chat-input-area">
        <AiSuggestionPanel
          :suggestion="aiSuggestion"
          :loading="aiSuggestionLoading"
          :error="aiSuggestionError"
          @generate="$emit('ask-ai')"
          @apply="applySuggestion"
        />

        <!-- Pending attachments preview -->
        <div v-if="pendingFiles.length" class="pending-files mb-2 pa-2">
          <div class="d-flex align-center mb-1">
            <v-icon size="16" class="mr-1">mdi-paperclip</v-icon>
            <span class="text-caption">{{ pendingFiles.length }} tệp đính kèm</span>
            <v-spacer />
            <v-btn size="x-small" variant="text" @click="pendingFiles = []">Xoá tất cả</v-btn>
          </div>
          <div class="d-flex flex-wrap gap-2">
            <div
              v-for="(f, i) in pendingFiles"
              :key="i"
              class="file-chip pa-1 d-flex align-center"
            >
              <img v-if="isImage(f)" :src="fileUrl(f)" class="file-thumb mr-2" />
              <v-icon v-else size="20" class="mr-2">{{ fileIcon(f) }}</v-icon>
              <div>
                <div class="text-caption">{{ f.name }}</div>
                <div class="text-caption text-grey">{{ humanSize(f.size) }}</div>
              </div>
              <v-btn icon="mdi-close" size="x-small" variant="text" @click="removeFile(i)" />
            </div>
          </div>
        </div>

        <div class="d-flex align-end" style="position: relative;">
          <QuickTemplatePopup
            ref="popupRef"
            :visible="showTemplatePopup"
            :query="templateQuery"
            :templates="templates"
            :contact="conversation.contact"
            @select="onTemplateSelect"
            @close="showTemplatePopup = false"
          />
          <input
            ref="fileInputEl"
            type="file"
            multiple
            style="display: none;"
            accept="image/*,video/*,.pdf,.doc,.docx,.xls,.xlsx,.ppt,.pptx,.txt,.zip,.rar"
            @change="onFilePicked"
          />
          <v-btn
            icon="mdi-paperclip"
            size="small"
            variant="text"
            class="mr-1"
            aria-label="Đính kèm"
            @click="fileInputEl?.click()"
          />
          <v-textarea
            v-model="inputText"
            :placeholder="pendingFiles.length ? 'Thêm chú thích (không bắt buộc)...' : 'Nhập tin nhắn... (gõ / để chèn mẫu)'"
            variant="solo-filled"
            density="compact"
            hide-details
            auto-grow
            rows="1"
            max-rows="3"
            class="flex-grow-1 mr-2"
            @input="onInput"
            @keydown="onInputKeydown"
            @keydown.enter.exact.prevent="handleSend"
            @paste="onPaste"
          />
          <v-btn icon color="primary" :loading="sending" :disabled="!canSend" @click="handleSend">
            <v-icon>mdi-send</v-icon>
          </v-btn>
        </div>
      </div>
    </template>

    <!-- Image preview dialog -->
    <v-dialog v-model="showImagePreview" max-width="900" content-class="elevation-0">
      <div class="text-center" @click="showImagePreview = false" style="cursor: pointer;">
        <img :src="previewImageUrl" alt="Preview" style="max-width: 100%; max-height: 85vh; border-radius: 12px; box-shadow: 0 8px 32px rgba(0,0,0,0.5);" />
        <div class="text-caption mt-2" style="color: #aaa;">Nhấn để đóng</div>
      </div>
    </v-dialog>

    <!-- Sync snackbar -->
    <v-snackbar v-model="syncSnack.show" :color="syncSnack.color" timeout="3000">{{ syncSnack.text }}</v-snackbar>
  </div>
</template>

<script setup lang="ts">
import { ref, watch, nextTick, computed, onMounted } from 'vue';
import type { Conversation, Message } from '@/composables/use-chat';
import { api } from '@/api/index';
import AiSuggestionPanel from '@/components/ai/ai-suggestion-panel.vue';
import SpecialMessageRenderer from '@/components/chat/special-message-renderer.vue';
import QuickTemplatePopup from '@/components/chat/quick-template-popup.vue';
import LinkifyText from '@/components/chat/LinkifyText.vue';

interface TemplateItem {
  id: string;
  name: string;
  content: string;
  category: string | null;
  isPersonal: boolean;
}

const props = defineProps<{
  conversation: Conversation | null;
  messages: Message[];
  loading: boolean;
  sending: boolean;
  showContactPanel?: boolean;
  aiSuggestion: string;
  aiSuggestionLoading: boolean;
  aiSuggestionError: string;
}>();

const emit = defineEmits<{
  send: [content: string];
  'send-attachments': [payload: { files: File[]; caption: string }];
  'toggle-contact-panel': [];
  'ask-ai': [];
}>();

const inputText = ref('');
const messagesContainer = ref<HTMLElement | null>(null);
const previewImageUrl = ref('');
const showImagePreview = computed({ get: () => !!previewImageUrl.value, set: (v) => { if (!v) previewImageUrl.value = ''; } });
const syncSnack = ref({ show: false, text: '', color: 'success' });

// --- File attachments (drag-drop + paste + paperclip) ---
const pendingFiles = ref<File[]>([]);
const isDragging = ref(false);
const fileInputEl = ref<HTMLInputElement | null>(null);
const fileUrlCache = new WeakMap<File, string>();
const MAX_FILE_SIZE = 50 * 1024 * 1024;

const canSend = computed(() => !!inputText.value.trim() || pendingFiles.value.length > 0);

function fileUrl(f: File): string {
  let url = fileUrlCache.get(f);
  if (!url) { url = URL.createObjectURL(f); fileUrlCache.set(f, url); }
  return url;
}
function isImage(f: File): boolean { return f.type.startsWith('image/'); }
function fileIcon(f: File): string {
  if (f.type.startsWith('video/')) return 'mdi-video';
  if (f.type.startsWith('audio/')) return 'mdi-music';
  if (f.type === 'application/pdf') return 'mdi-file-pdf-box';
  return 'mdi-file-document-outline';
}
function humanSize(n: number): string {
  if (n >= 1048576) return `${(n / 1048576).toFixed(1)} MB`;
  if (n >= 1024) return `${Math.round(n / 1024)} KB`;
  return `${n} B`;
}
function addFiles(list: FileList | File[] | null) {
  if (!list) return;
  const arr = Array.from(list);
  const valid: File[] = [];
  for (const f of arr) {
    if (f.size > MAX_FILE_SIZE) {
      syncSnack.value = { show: true, text: `"${f.name}" vượt quá 50MB`, color: 'warning' };
      continue;
    }
    valid.push(f);
  }
  pendingFiles.value = [...pendingFiles.value, ...valid];
}
function removeFile(i: number) {
  const f = pendingFiles.value[i];
  const url = fileUrlCache.get(f);
  if (url) URL.revokeObjectURL(url);
  pendingFiles.value = pendingFiles.value.filter((_, idx) => idx !== i);
}
function onFilePicked(e: Event) {
  const input = e.target as HTMLInputElement;
  addFiles(input.files);
  input.value = '';
}
function onDragOver(e: DragEvent) {
  if (e.dataTransfer?.types?.includes('Files')) isDragging.value = true;
}
function onDragLeave(e: DragEvent) {
  // Only clear when leaving the outer container
  if ((e.target as HTMLElement).classList.contains('message-thread')) isDragging.value = false;
  else if (!e.relatedTarget) isDragging.value = false;
}
function onDrop(e: DragEvent) {
  isDragging.value = false;
  if (e.dataTransfer?.files) addFiles(e.dataTransfer.files);
}
function onPaste(e: ClipboardEvent) {
  const items = e.clipboardData?.items;
  if (!items) return;
  const files: File[] = [];
  for (const it of items) {
    if (it.kind === 'file') {
      const f = it.getAsFile();
      if (f) files.push(f);
    }
  }
  if (files.length) { e.preventDefault(); addFiles(files); }
}

// Content types handled by SpecialMessageRenderer
const SPECIAL_TYPES = new Set([
  'bank_transfer', 'call', 'qr_code', 'reminder', 'poll', 'note', 'forwarded', 'rich',
]);

function isSpecialType(contentType: string | null | undefined): boolean {
  return !!contentType && SPECIAL_TYPES.has(contentType);
}

/** Safely parse JSON content for SpecialMessageRenderer; returns raw string on failure. */
function parseContent(content: string | null): unknown {
  if (!content) return null;
  try { return JSON.parse(content); } catch { return content; }
}

// --- Template quick-insert ---
const showTemplatePopup = ref(false);
const templateQuery = ref('');
const templates = ref<TemplateItem[]>([]);
const popupRef = ref<InstanceType<typeof QuickTemplatePopup> | null>(null);

async function loadTemplates() {
  try {
    const res = await api.get<{ templates: TemplateItem[] }>('/automation/templates');
    templates.value = res.data.templates;
  } catch {
    // Non-critical — popup shows empty list on failure
  }
}

onMounted(() => { loadTemplates(); });

/** Detect `/` trigger: at start of input or immediately after a space */
function onInput(e: Event) {
  const value = (e.target as HTMLTextAreaElement).value;
  if (value === '/' || /\s\/$/.test(value)) {
    showTemplatePopup.value = true;
    templateQuery.value = '';
  } else if (showTemplatePopup.value) {
    const lastSlash = value.lastIndexOf('/');
    if (lastSlash === -1) {
      showTemplatePopup.value = false;
    } else {
      templateQuery.value = value.slice(lastSlash + 1);
    }
  }
}

/** Forward arrow/enter/escape keys to popup when open */
function onInputKeydown(e: KeyboardEvent) {
  if (!showTemplatePopup.value) return;
  if (['ArrowUp', 'ArrowDown', 'Enter', 'Escape'].includes(e.key)) {
    popupRef.value?.onKey(e);
  }
}

function onTemplateSelect(rendered: string) {
  const lastSlash = inputText.value.lastIndexOf('/');
  inputText.value = lastSlash >= 0 ? inputText.value.slice(0, lastSlash) + rendered : rendered;
  showTemplatePopup.value = false;
  templateQuery.value = '';
}
// --- End template quick-insert ---

function handleSend() {
  if (showTemplatePopup.value) { showTemplatePopup.value = false; return; }
  if (pendingFiles.value.length > 0) {
    emit('send-attachments', { files: pendingFiles.value, caption: inputText.value });
    for (const f of pendingFiles.value) {
      const url = fileUrlCache.get(f);
      if (url) URL.revokeObjectURL(url);
    }
    pendingFiles.value = [];
    inputText.value = '';
    return;
  }
  if (!inputText.value.trim()) return;
  emit('send', inputText.value);
  inputText.value = '';
}

function applySuggestion() { if (!props.aiSuggestion) return; inputText.value = props.aiSuggestion; }
function formatMessageTime(d: string) { return new Date(d).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }); }
function openFile(url: string) { window.open(url, '_blank'); }

/** Extract image URL from JSON content */
function getImageUrl(msg: Message): string | null {
  if (msg.contentType === 'image' && msg.content) {
    if (msg.content.startsWith('http')) return msg.content;
    try { const p = JSON.parse(msg.content); return p.href || p.thumb || p.hdUrl || null; } catch {}
  }
  if (msg.content?.startsWith('{')) {
    try {
      const p = JSON.parse(msg.content);
      const href = p.href || p.thumb || '';
      if (href && /\.(jpg|jpeg|png|webp|gif)/i.test(href)) return href;
      if (href && href.includes('zdn.vn') && !p.params?.includes('fileExt')) return href;
    } catch {}
  }
  return null;
}

/** Extract video playback info from JSON content. Zalo video = { href, thumb, params: { fileSize, duration } }. */
function getVideoInfo(msg: Message): { src: string; poster: string; sizeLabel: string } | null {
  if (!msg.content?.startsWith('{')) return null;
  try {
    const p = JSON.parse(msg.content);
    const src = p.href || '';
    if (!src) return null;
    const poster = p.thumb || '';
    let sizeLabel = '';
    try {
      const params = typeof p.params === 'string' ? JSON.parse(p.params) : p.params;
      const bytes = parseInt(params?.fileSize || '0');
      if (bytes > 0) sizeLabel = bytes > 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`;
    } catch { /* ignore param parse errors — size label is optional */ }
    return { src, poster, sizeLabel };
  } catch {
    return null;
  }
}

/** Extract voice audio URL from JSON content. */
function getVoiceUrl(msg: Message): string | null {
  if (!msg.content) return null;
  if (msg.content.startsWith('http')) return msg.content;
  if (!msg.content.startsWith('{')) return null;
  try {
    const p = JSON.parse(msg.content);
    return p.href || p.url || null;
  } catch {
    return null;
  }
}

/** Extract file info from JSON content (PDF, docs, etc.) */
function getFileInfo(msg: Message): { name: string; size: string; href: string } | null {
  if (!msg.content?.startsWith('{')) return null;
  try {
    const p = JSON.parse(msg.content);
    const params = typeof p.params === 'string' ? JSON.parse(p.params) : p.params;
    if (params?.fileExt || params?.fType === 1) {
      const bytes = parseInt(params.fileSize || '0');
      const size = bytes > 1048576 ? `${(bytes / 1048576).toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`;
      return { name: p.title || `file.${params.fileExt || 'unknown'}`, size, href: p.href || '' };
    }
  } catch {}
  return null;
}

function parseDisplayContent(content: string | null): string {
  if (!content) return '';
  if (!content.startsWith('{')) return content;
  try {
    const p = JSON.parse(content);
    if (p.title && p.href) return `🔗 ${p.title}`;
    if (p.title) return p.title;
    if (p.href) return `🔗 ${p.description || p.href}`;
    return content;
  } catch { return content; }
}

function isReminderMessage(msg: Message): boolean {
  if (!msg.content) return false;
  try { const p = JSON.parse(msg.content); return p.action === 'msginfo.actionlist'; } catch { return false; }
}

function getReminderTitle(msg: Message): string {
  try { return JSON.parse(msg.content!).title || ''; } catch { return msg.content || ''; }
}

function getReminderTime(msg: Message): string | null {
  try {
    const p = JSON.parse(msg.content!);
    const params = typeof p.params === 'string' ? JSON.parse(p.params) : p.params;
    for (const h of (params?.highLightsV2 || [])) {
      if (h.ts > 1e12) return new Date(h.ts).toLocaleString('vi-VN', { weekday: 'long', day: '2-digit', month: '2-digit', year: 'numeric', hour: '2-digit', minute: '2-digit' });
    }
  } catch {}
  return null;
}

/** Sync Zalo reminder to CRM appointments via API */
async function syncAppointment(msg: Message) {
  if (!props.conversation?.contact?.id) { syncSnack.value = { show: true, text: 'Không có thông tin khách hàng', color: 'error' }; return; }
  try {
    const p = JSON.parse(msg.content!);
    const params = typeof p.params === 'string' ? JSON.parse(p.params) : p.params;
    let appointmentDate: string | null = null;
    for (const h of (params?.highLightsV2 || [])) {
      if (h.ts > 1e12) { appointmentDate = new Date(h.ts).toISOString(); break; }
    }
    if (!appointmentDate) { syncSnack.value = { show: true, text: 'Không tìm thấy thời gian hẹn', color: 'warning' }; return; }
    await api.post('/appointments', {
      contactId: props.conversation.contact.id,
      appointmentDate,
      appointmentTime: new Date(appointmentDate).toLocaleTimeString('vi-VN', { hour: '2-digit', minute: '2-digit' }),
      type: 'tai_kham',
      notes: `[Zalo] ${p.title || ''}`,
    });
    syncSnack.value = { show: true, text: 'Đã đồng bộ lịch hẹn thành công!', color: 'success' };
  } catch (err: unknown) {
    const e = err as { response?: { data?: { error?: string } } };
    syncSnack.value = { show: true, text: e.response?.data?.error || 'Đồng bộ thất bại', color: 'error' };
  }
}

watch(() => props.messages.length, async () => { await nextTick(); if (messagesContainer.value) messagesContainer.value.scrollTop = messagesContainer.value.scrollHeight; });
</script>

<style scoped>
.message-bubble { box-shadow: 0 1px 2px rgba(0, 0, 0, 0.1); }
.reminder-card { padding: 8px 12px; border-left: 3px solid #FFB74D; border-radius: 8px; background: rgba(255, 183, 77, 0.08); }
.file-card { display: flex; align-items: center; padding: 8px 12px; border-radius: 8px; background: rgba(0, 242, 255, 0.05); border: 1px solid rgba(0, 242, 255, 0.1); }
.chat-image { max-width: 100%; max-height: 300px; border-radius: 12px; cursor: pointer; transition: transform 0.2s; }
.chat-image:hover { transform: scale(1.02); }
.chat-video { max-width: 320px; max-height: 320px; border-radius: 10px; display: block; background: #000; }
.chat-audio { max-width: 280px; }
.video-wrap { display: inline-block; max-width: 100%; }
.drop-overlay {
  position: absolute;
  inset: 0;
  background: rgba(10, 25, 47, 0.9);
  border: 2px dashed #00F2FF;
  border-radius: 12px;
  z-index: 20;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  pointer-events: none;
}
.pending-files {
  border: 1px solid rgba(0, 242, 255, 0.2);
  border-radius: 8px;
  background: rgba(0, 242, 255, 0.04);
}
.file-chip {
  border: 1px solid rgba(0, 242, 255, 0.15);
  border-radius: 8px;
  background: rgba(255, 255, 255, 0.04);
  max-width: 240px;
}
.file-thumb {
  width: 32px;
  height: 32px;
  object-fit: cover;
  border-radius: 4px;
}
</style>
